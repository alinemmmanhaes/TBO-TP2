/*
Trabalho 2 - TBO
Aline Manhães - 2023100253
Maria Luiza Ferreira - 2023101579
Raony Togneri - 2023102512
*/

#ifndef _BT_H_
#define _BT_H_


typedef struct BT BT;
typedef struct Node Node;

#define NODE_CHAVE 0
#define NODE_PAI 1

/// @brief cria árvore b, com 0 nós, raiz nula e ordem do parâmetro
/// @param ordem ordem da árvore
/// @return BT*: ponteiro da BT criada
BT *criaBT(int ordem);

/// @brief insere uma chave na BT, seguindo os possíveis casos de inserção
/// @param bt ponteiro para BT
/// @param chave chave a ser inserida
/// @param registro registro a ser inserido
/// @param arq ponteiro para o arquivo binário
void insereBT(BT *bt, int chave, int registro, FILE *arq);

/// @brief remove uma chave da BT, seguindo as invariantes e os casos dos slides
/// @param bt ponteiro para BT
/// @param chave chave a ser removida
/// @param arq ponteiro para o arquivo binário
void removeBT(BT *bt, int chave, FILE *arq);

/// @brief busca uma chave na BT
/// @param node ponteiro para o nó onde será feita a busca
/// @param pai ponteiro para o pai do nó (pode ser NULL)
/// @param chave chave a ser buscada
/// @param MODO_BUSCA NODE_CHAVE ou NODE_PAI, a depender do interesse da busca
/// @param arq ponteiro para o arquivo binário
/// @return Nó com a chave, ou NULL caso inexistente
Node *buscaBT(Node *node, Node *pai, int chave, int MODO_BUSCA, FILE *arq);

/// @brief printa a árvore utilizando uma fila, para imprimir a BT com alturas diferentes
/// @param bt ponteiro para árvore
/// @param arq ponteiro para o arquivo de saída onde será printada
/// @param bin ponteiro para o arquivo binário
void printBT(BT* bt, FILE* arq, FILE *bin);

/// @brief insere chave e registros em um node
/// @param n ponteiro para o node que receberá chave e o registro
/// @param chave chave a ser inserida
/// @param registro registro a ser inserido
/// @param ind índice da posição a ser inserida no node
void insereChaveRegistro(Node *n, int chave, int registro, int ind);

/// @brief retorna a raiz da BT
/// @param bt ponteiro para BT
/// @return ponteiro para a raiz
Node *getRaizBT(BT* bt);

/// @brief retorna a ordem da BT
/// @param bt ponteiro para BT
/// @return inteiro que representa a ordem da árvore
int getOrdemBT(BT *bt);

/// @brief retorna o número de nós da árvore
/// @param bt ponteiro para BT
/// @return número de nós da BT
int getNumNosBT(BT *bt);

/// @brief libera a memória da BT
/// @param bt ponteiro para BT
void liberaBT(BT *bt);

/// @brief libera a memória do node
/// @param node ponteiro para node
/// @return node null
Node *liberaNode(Node *node);

/// @brief lê um nó do arquivo binário
/// @param offset deslocamento do nó no arquivo binário
/// @param ordem ordem da árvore b
/// @param fp arquivo binário
/// @return nó lido
Node *diskRead(int offset, int ordem, FILE *fp);

/// @brief escreve um nó no binário
/// @param node nó a ser escrito
/// @param order ordem da árvore b
/// @param fp arquivo binário
void diskWrite(Node *node, int order, FILE *fp);

#endif // !_BT_H_
/*
Trabalho 2 - TBO
Aline Manhães - 2023100253
Maria Luiza Ferreira - 2023101579
Raony Togneri - 2023102512
*/

#if !defined(FILA_H)
#define FILA_H

typedef struct fila Fila;

/// @brief Cria a fila, com tudo inicializado vazio
/// @return Fila*: ponteiro para fila criada
Fila* criaFila();

/// @brief insere um item no fim da fila
/// @param fila ponteiro para fila
/// @param item item a ser inserido
void insereFila(Fila* fila, void* item);

/// @brief remove o primeiro item da fila
/// @param fila ponteiro para fila
/// @return void*: ponteiro para o item removido
void* removeFila(Fila* fila);

/// @brief libera a fila e suas células
/// @param fila ponteiro para fila
void liberaFila(Fila* fila);

/// @brief verifica se a fila é vazia
/// @param fila ponteiro para fila
/// @return 1, se está vazia, 0, se não está
int filaVazia(Fila* fila);

#endif // FILA_H
